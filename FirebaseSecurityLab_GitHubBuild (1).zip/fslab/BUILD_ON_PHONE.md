# Build the APK from your phone (GitHub Actions)

You do not need a computer or Android Studio.

1. Create a GitHub account if you do not already have one.
2. Create a new repository, for example `FirebaseSecurityLab`.
3. Upload all files/folders from this project to the repository, including `.github/workflows/build-apk.yml`.
4. Open the repository on GitHub.
5. Go to **Actions** → **Build Android APK**.
6. Open the latest successful workflow run.
7. Under **Artifacts**, download `FirebaseSecurityLab-debug-apk`.
8. Extract the downloaded artifact and install `app-debug.apk` on your Android phone.

The workflow builds a debug APK using JDK 17, Android SDK 35 and Gradle 8.9.

Important: use the app only with Firebase projects you own or are authorized to test.
