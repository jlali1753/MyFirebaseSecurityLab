package com.example.firebasesecuritylab

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DatabaseReference
import org.json.JSONObject
import java.util.Date

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: android.widget.EditText
    private lateinit var pathInput: android.widget.EditText
    private lateinit var jsonInput: android.widget.EditText
    private lateinit var status: TextView
    private var auth: FirebaseAuth? = null
    private var database: FirebaseDatabase? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.databaseUrl)
        pathInput = findViewById(R.id.path)
        jsonInput = findViewById(R.id.jsonData)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.authBtn).setOnClickListener { anonymousSignIn() }
        findViewById<Button>(R.id.signOutBtn).setOnClickListener {
            auth?.signOut()
            status.text = "Signed out"
        }

        findViewById<Button>(R.id.readBtn).setOnClickListener { runRead() }
        findViewById<Button>(R.id.writeBtn).setOnClickListener { runWrite() }
        findViewById<Button>(R.id.updateBtn).setOnClickListener { runUpdate() }
        findViewById<Button>(R.id.deleteBtn).setOnClickListener { runDelete() }
    }

    private fun connect(): DatabaseReference? {
        val url = urlInput.text.toString().trim()
        if (!url.startsWith("https://") || !url.contains("firebaseio.com")) {
            status.text = "Invalid Firebase Realtime Database URL"
            return null
        }

        return try {
            val options = FirebaseOptions.Builder()
                .setApplicationId("1:000000000000:android:securitylab")
                .setProjectId("firebase-security-lab")
                .setApiKey("not-used-for-database-rules-test")
                .setDatabaseUrl(url)
                .build()

            val appName = "lab-${url.hashCode()}"
            val app = try {
                FirebaseApp.getInstance(appName)
            } catch (_: Exception) {
                FirebaseApp.initializeApp(this, options, appName)
            }

            database = FirebaseDatabase.getInstance(app)
            auth = FirebaseAuth.getInstance(app)
            database!!.reference.child(cleanPath()).also {
                status.text = "Connected to: $url"
            }
        } catch (e: Exception) {
            status.text = "Connection error: ${e.message}"
            null
        }
    }

    private fun cleanPath(): String =
        pathInput.text.toString().trim().trim('/')

    private fun runRead() {
        val ref = connect() ?: return
        val started = Date()
        ref.get().addOnCompleteListener { task ->
            val elapsed = System.currentTimeMillis() - started.time
            if (task.isSuccessful) {
                status.text = "READ: ALLOWED\nPath: /${cleanPath()}\nTime: ${elapsed} ms\nData:\n${task.result.value}"
            } else {
                status.text = "READ: DENIED / ERROR\nPath: /${cleanPath()}\nTime: ${elapsed} ms\n${task.exception?.message}"
            }
        }
    }

    private fun parseJson(): Map<String, Any?>? {
        return try {
            val obj = JSONObject(jsonInput.text.toString())
            obj.keys().asSequence().associateWith { obj.get(it) }
        } catch (e: Exception) {
            status.text = "Invalid JSON: ${e.message}"
            null
        }
    }

    private fun runWrite() {
        val ref = connect() ?: return
        val data = parseJson() ?: return
        ref.setValue(data).addOnCompleteListener { task ->
            status.text = if (task.isSuccessful)
                "WRITE: ALLOWED\nPath: /${cleanPath()}"
            else
                "WRITE: DENIED / ERROR\n${task.exception?.message}"
        }
    }

    private fun runUpdate() {
        val ref = connect() ?: return
        val data = parseJson() ?: return
        ref.updateChildren(data).addOnCompleteListener { task ->
            status.text = if (task.isSuccessful)
                "UPDATE: ALLOWED\nPath: /${cleanPath()}"
            else
                "UPDATE: DENIED / ERROR\n${task.exception?.message}"
        }
    }

    private fun runDelete() {
        val ref = connect() ?: return
        ref.removeValue().addOnCompleteListener { task ->
            status.text = if (task.isSuccessful)
                "DELETE: ALLOWED\nPath: /${cleanPath()}"
            else
                "DELETE: DENIED / ERROR\n${task.exception?.message}"
        }
    }

    private fun anonymousSignIn() {
        val ref = connect()
        if (ref == null) return
        auth!!.signInAnonymously().addOnCompleteListener { task ->
            status.text = if (task.isSuccessful)
                "Authenticated anonymously\nUID: ${auth!!.currentUser?.uid}"
            else
                "Authentication failed: ${task.exception?.message}"
        }
    }
}
