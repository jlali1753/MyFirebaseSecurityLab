# Firebase Security Lab

Android Studio project for authorized testing of Firebase Realtime Database Security Rules.

## Build directly in Android Studio
1. Open the `FirebaseSecurityLab` folder in Android Studio.
2. If Android Studio asks for the Gradle JDK, select the bundled JDK (17 or newer).
3. Install Android SDK Platform 35 if requested.
4. Sync Gradle.
5. Select **Build > Build APK(s)**.

This version does **not** require `google-services.json`. Firebase configuration is supplied in the app at runtime using the Realtime Database URL.

## Test
- Enter a Firebase Realtime Database URL belonging to a project you own or are authorized to test.
- Enter a database path.
- Optionally use Anonymous Authentication if enabled in that Firebase project.
- Test READ, WRITE, UPDATE, and DELETE.

The app reports successful operations and Firebase rule/authentication errors.
